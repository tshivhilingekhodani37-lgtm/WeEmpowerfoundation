package com.example.weempowerfoundationapp

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.weempowerfoundationapp.R.id.etEventDescription
import java.util.Calendar

class Volunteer : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_volunteer)

        val etEventDescription = findViewById<EditText>(etEventDescription)
        val btnPickDate = findViewById<Button>(R.id.btnPickDate)
        val btnSubmitVolunteer = findViewById<Button>(R.id.btnSubmitVolunteer)

        btnPickDate.setOnClickListener {
            val calendar = Calendar.getInstance()
            val datePicker = DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    val selectedDate = "$dayOfMonth/${month + 1}/$year"
                    btnPickDate.text = selectedDate
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            datePicker.show()
        }

        btnSubmitVolunteer.setOnClickListener {
            val description = etEventDescription.text.toString()
            val date = btnPickDate.text.toString()

            if (description.isNotEmpty() && date != "Pick Date") {
                Toast.makeText(
                    this,
                    "Volunteer Scheduled: $description on $date",
                    Toast.LENGTH_SHORT
                ).show()
                // Here you could add code to save to a database or perform other actions
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }

    }
}