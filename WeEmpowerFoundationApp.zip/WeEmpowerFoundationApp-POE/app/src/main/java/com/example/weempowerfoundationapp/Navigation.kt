package com.example.weempowerfoundationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Telephony.Mms.Intents
import android.view.View
import android.widget.TextView

class Navigation : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navigation)

        val volunteerLink = findViewById<TextView>(R.id.Volunteer_link)
        val homeLink = findViewById<TextView>(R.id.home_link)
        val newsLink = findViewById<TextView>(R.id.news_link)
        val donateLink = findViewById<TextView>(R.id.donate_link)
        val mentalhealthLink = findViewById<TextView>(R.id.MentalHealth_link)
        val contactUsLink = findViewById<TextView>(R.id.contactUs_link)



        homeLink.setOnClickListener {
            // Handle home link click
            // Navigate to HomeActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        newsLink.setOnClickListener {
            // Handle news link click
            // Navigate to NewsActivity
            val intent = Intent(this, News::class.java)
            startActivity(intent)
        }

        donateLink.setOnClickListener {
            // Handle donate link click
            // Navigate to DonateActivity
            val intent = Intent(this, Donation::class.java)
            startActivity(intent)
        }

        contactUsLink.setOnClickListener {
            // Handle contactus link click
            // Navigate to contactus page
            val intent = Intent(this, ContactUs::class.java)
            startActivity(intent)
        }
        mentalhealthLink.setOnClickListener {
            // Handle mental health link click
            // Navigate to mental health page
            val intent = Intent(this, MentalHealth::class.java)
            startActivity(intent)
        }
        volunteerLink.setOnClickListener {
            // Handle volunteer link click
            // Navigate to volunteer page
            val intent = Intent(this, Volunteer::class.java)
            startActivity(intent)
        }

    }
}
