package com.example.weempowerfoundationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import android.content.Context
import android.content.SharedPreferences
import android.widget.Button

class MentalHealth : AppCompatActivity() {

    private lateinit var editTextNote: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mental_health)

        editTextNote = findViewById(R.id.editTextNote)
        btnSave = findViewById(R.id.btnSave)

        // Set up click listener for the save button
        btnSave.setOnClickListener {
            val note = editTextNote.text.toString()
            if (note.isEmpty()) {
                Toast.makeText(this, "Please enter a note", Toast.LENGTH_SHORT).show()
            } else {
                // TODO: Implement save logic (e.g., save to a local database)
                Toast.makeText(this, "Note saved successfully!", Toast.LENGTH_SHORT).show()
                editTextNote.text.clear() // Clear the input field after saving
            }
    }


        //button to go to Navigation page
        val mental = findViewById<Button>(R.id.button_mental)
        mental.setOnClickListener {
            val intent = Intent(this, Navigation::class.java)
            startActivity(intent)
        }
    }
}