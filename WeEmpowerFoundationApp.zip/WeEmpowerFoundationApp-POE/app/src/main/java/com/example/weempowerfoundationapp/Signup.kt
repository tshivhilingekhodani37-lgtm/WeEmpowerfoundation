package com.example.weempowerfoundationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class Signup : AppCompatActivity() {

    private lateinit var auth:FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        auth = FirebaseAuth.getInstance()

        // Initialize user interface elements
        val loginButton = findViewById<Button>(R.id.login)
        val emailEditText = findViewById<EditText>(R.id.email)
        val passwordEditText = findViewById<EditText>(R.id.password)

        //login button to link to next page
        val button = findViewById<Button>(R.id.button__kk)
        button.setOnClickListener {
            val intent = Intent(this,Navigation::class.java)
            startActivity(intent)
        }

        loginButton.setOnClickListener {
            // Handle login button click
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            //input fields
            if (email.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            //firebase authentication
            auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, Navigation::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(
                        this,
                        "Login failed:${task.exception?.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

    }
}