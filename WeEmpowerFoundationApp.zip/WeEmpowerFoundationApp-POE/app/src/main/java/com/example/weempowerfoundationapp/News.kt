package com.example.weempowerfoundationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.widget.Button
import android.webkit.WebSettings
import android.webkit.WebViewClient

class News : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news)

        val newsWebView = findViewById<WebView>(R.id.newsWebView)

        // Enable JavaScript for the WebView
        val webSettings: WebSettings = newsWebView.settings
        webSettings.javaScriptEnabled = true

        // Ensure links open within the WebView and not in a browser
        newsWebView.webViewClient = WebViewClient()

        // Load the news website
        newsWebView.loadUrl("https://www.citizen.co.za/soweto-urban/news-headlines/local-news/2024/05/19/npos-get-good-news-from-gauteng-government-about-funding/")

        //button to link to navigation page
        val nav = findViewById<Button>(R.id.navigate1)
        nav.setOnClickListener {
            val intent = Intent(this, Navigation::class.java)
            startActivity(intent)
        }
    }
}
