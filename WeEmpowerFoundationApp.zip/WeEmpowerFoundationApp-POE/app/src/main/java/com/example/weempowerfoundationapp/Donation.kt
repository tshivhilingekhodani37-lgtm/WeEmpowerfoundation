package com.example.weempowerfoundationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.paypal.android.sdk.payments.PayPalConfiguration
import com.paypal.android.sdk.payments.PayPalPayment
import com.paypal.android.sdk.payments.PayPalService
import com.paypal.android.sdk.payments.PaymentActivity
import com.paypal.android.sdk.payments.PaymentConfirmation
import java.math.BigDecimal

class Donation : AppCompatActivity() {

    private val config = PayPalConfiguration()
        .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX)
        .clientId("ATSq4gYzbdqzRblu1xk4IYmoi03jibuNh-e3sRJx0bCVlgv2HpV_dtRjIQNs2ianRj7ALq68ilzBmn9O")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donation)

                val donationAmountEditText = findViewById<EditText>(R.id.donationAmountEditText)
                val donateButton = findViewById<Button>(R.id.donateButton)

                // Start PayPal Service
                val intent = Intent(this, PayPalService::class.java)
                intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config)
                startService(intent)

                donateButton.setOnClickListener {
                    val amount = donationAmountEditText.text.toString().trim()

                    if (amount.isNotEmpty()) {
                        val payment = PayPalPayment(
                            BigDecimal(amount),
                            "USD",
                            "Donation",
                            PayPalPayment.PAYMENT_INTENT_SALE
                        )

                        val intent = Intent(this, PaymentActivity::class.java)
                        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config)
                        intent.putExtra(PaymentActivity.EXTRA_PAYMENT, payment)
                        startActivityForResult(intent, REQUEST_CODE_PAYMENT)
                    } else {
                        // Handle error
                    }
                }
            }

            override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
                super.onActivityResult(requestCode, resultCode, data)

                if (requestCode == REQUEST_CODE_PAYMENT) {
                    if (resultCode == RESULT_OK) {
                        val confirmation: PaymentConfirmation? =
                            data?.getParcelableExtra(PaymentActivity.EXTRA_RESULT_CONFIRMATION)
                        if (confirmation != null) {
                            // Payment successful
                        }
                    } else if (resultCode == RESULT_CANCELED) {
                        // Payment cancelled
                    } else if (resultCode == PaymentActivity.RESULT_EXTRAS_INVALID) {
                        // Invalid payment / configuration submitted
                    }
                }
            }

            override fun onDestroy() {
                super.onDestroy()
                // Stop PayPal Service
                stopService(Intent(this, PayPalService::class.java))
            }

            companion object {
                private const val REQUEST_CODE_PAYMENT = 1
            }
        }