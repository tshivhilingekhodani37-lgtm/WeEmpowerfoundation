package com.example.weempowerfoundationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import com.paypal.android.sdk.payments.PayPalConfiguration

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val config = PayPalConfiguration()
            .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX)
            .clientId("ATSq4gYzbdqzRblu1xk4IYmoi03jibuNh-e3sRJx0bCVlgv2HpV_dtRjIQNs2ianRj7ALq68ilzBmn9O")


        val emailEditText = findViewById<EditText>(R.id.email)
        val passwordEditText = findViewById<EditText>(R.id.password)
        val termsAndConditionsCheckBox = findViewById<CheckBox>(R.id.terms_and_conditions)
        val signup = findViewById<Button>(R.id.sign_up)
        val socialMediaIconsLinearLayout = findViewById<LinearLayout>(R.id.social_media_icons)

        //signup button to link to next page
        val signupbutton = findViewById<Button>(R.id.sign_up)
        signupbutton.setOnClickListener {
            val intent = Intent(this,Signup::class.java)
                startActivity(intent)
        }

    }
}

